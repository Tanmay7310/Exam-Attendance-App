import React, { useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { useAuth } from '../context/AuthContext';
import { colors } from '../styles/theme';

export const LoginScreen = () => {
  const { login } = useAuth();
  const [username, setUsername] = useState('teacher1');
  const [password, setPassword] = useState('Teacher@123');
  const [loading, setLoading] = useState(false);

  const onSubmit = async () => {
    try {
      setLoading(true);
      await login(username.trim(), password);
    } catch (e: any) {
      Alert.alert('Login failed', e?.response?.data?.message ?? 'Unable to login');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Exam Attendance</Text>
      <Text style={styles.subtitle}>Teacher/Admin secure login</Text>

      <TextInput value={username} onChangeText={setUsername} placeholder="Username" style={styles.input} autoCapitalize="none" />
      <TextInput value={password} onChangeText={setPassword} placeholder="Password" style={styles.input} secureTextEntry />

      <Pressable style={styles.button} disabled={loading} onPress={onSubmit}>
        <Text style={styles.buttonText}>{loading ? 'Signing in...' : 'Login'}</Text>
      </Pressable>

      <Text style={styles.hint}>Use admin1/Admin@123 or teacher1/Teacher@123</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 24,
    backgroundColor: colors.bg
  },
  title: {
    fontSize: 32,
    fontWeight: '800',
    color: colors.text,
    marginBottom: 6
  },
  subtitle: {
    color: colors.textMuted,
    marginBottom: 18
  },
  input: {
    backgroundColor: colors.card,
    borderColor: colors.border,
    borderWidth: 1,
    borderRadius: 12,
    padding: 14,
    marginBottom: 12
  },
  button: {
    backgroundColor: colors.accent,
    borderRadius: 12,
    padding: 14,
    marginTop: 8,
    alignItems: 'center'
  },
  buttonText: {
    color: 'white',
    fontWeight: '700'
  },
  hint: {
    marginTop: 16,
    color: colors.textMuted,
    fontSize: 12
  }
});
