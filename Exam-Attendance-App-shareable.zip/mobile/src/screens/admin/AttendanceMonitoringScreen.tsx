import React, { useCallback, useState } from 'react';
import { Alert, FlatList, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import * as FileSystem from 'expo-file-system/legacy';
import * as Sharing from 'expo-sharing';
import { api } from '../../api/client';
import { useAuth } from '../../context/AuthContext';
import { AdminAttendance } from '../../types';
import { colors } from '../../styles/theme';

const isValidDateParam = (value: string) => {
  if (!value.trim()) return true;
  const match = value.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!match) return false;

  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  const parsedUtc = new Date(Date.UTC(year, month - 1, day));

  return parsedUtc.getUTCFullYear() === year
    && parsedUtc.getUTCMonth() === month - 1
    && parsedUtc.getUTCDate() === day;
};

export const AttendanceMonitoringScreen = () => {
  const { auth } = useAuth();
  const [date, setDate] = useState('');
  const [teacherId, setTeacherId] = useState('');
  const [subject, setSubject] = useState('');
  const [rows, setRows] = useState<AdminAttendance[]>([]);

  const fetchRows = useCallback(async () => {
    const dateValue = date.trim();
    if (!isValidDateParam(dateValue)) {
      return;
    }

    const params: any = {};
    if (dateValue) params.date = dateValue;
    if (teacherId) params.teacherId = teacherId.trim();
    if (subject) params.subject = subject;

    const { data } = await api.get<AdminAttendance[]>('/api/admin/attendance', { params });
    setRows(data);
  }, [date, teacherId, subject]);

  React.useEffect(() => {
    fetchRows().catch(() => Alert.alert('Error', 'Failed to load attendance records'));
  }, [fetchRows]);

  const exportPdf = async () => {
    try {
      const dateValue = date.trim();
      if (!isValidDateParam(dateValue)) {
        Alert.alert('Invalid date', 'Please enter date in YYYY-MM-DD format.');
        return;
      }

      const params: string[] = [];
      if (dateValue) params.push(`date=${encodeURIComponent(dateValue)}`);
      if (teacherId) params.push(`teacherId=${encodeURIComponent(teacherId)}`);
      if (subject) params.push(`subject=${encodeURIComponent(subject)}`);
      const query = params.length ? `?${params.join('&')}` : '';

      const fileUri = `${FileSystem.documentDirectory}admin-attendance-${Date.now()}.pdf`;
      const url = `${api.defaults.baseURL}/api/admin/attendance/report/pdf${query}`;

      await FileSystem.downloadAsync(url, fileUri, {
        headers: {
          Authorization: `Bearer ${auth?.token ?? ''}`
        }
      });

      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(fileUri);
      } else {
        Alert.alert('Saved', `PDF saved at ${fileUri}`);
      }
    } catch (e: any) {
      Alert.alert('Export failed', e?.response?.data?.message ?? 'Unable to generate PDF');
    }
  };

  const clearFilters = () => {
    setDate('');
    setTeacherId('');
    setSubject('');
  };

  return (
    <View style={styles.container}>
      <TextInput placeholder="Date (YYYY-MM-DD)" value={date} onChangeText={setDate} style={styles.input} />
      <TextInput placeholder="Teacher (ID/Code/Name optional)" value={teacherId} onChangeText={setTeacherId} style={styles.input} />
      <TextInput placeholder="Subject (optional)" value={subject} onChangeText={setSubject} style={styles.input} />
      <View style={styles.actionRow}>
        <Pressable style={[styles.button, styles.secondaryButton]} onPress={clearFilters}>
          <Text style={styles.buttonText}>Clear Filters</Text>
        </Pressable>
        <Pressable style={styles.button} onPress={exportPdf}>
          <Text style={styles.buttonText}>Export PDF</Text>
        </Pressable>
      </View>

      <FlatList
        style={{ marginTop: 10 }}
        data={rows}
        keyExtractor={(item) => `${item.scholarNumber}-${item.scannedAt}`}
        ListEmptyComponent={<Text style={styles.empty}>No attendance records found.</Text>}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Text style={styles.name}>{item.studentName} ({item.scholarNumber})</Text>
            <Text style={styles.meta}>{item.teacherName} [{item.teacherCode}] - {item.subject}</Text>
            <Text style={styles.meta}>{new Date(item.scannedAt).toLocaleString()}</Text>
          </View>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 12, backgroundColor: colors.bg },
  input: {
    backgroundColor: colors.card,
    borderColor: colors.border,
    borderWidth: 1,
    borderRadius: 10,
    padding: 10,
    marginBottom: 7
  },
  actionRow: { flexDirection: 'row', gap: 8 },
  button: { flex: 1, backgroundColor: colors.accent, borderRadius: 10, padding: 12, alignItems: 'center' },
  secondaryButton: { backgroundColor: colors.textMuted },
  buttonText: { color: 'white', fontWeight: '700' },
  card: {
    backgroundColor: colors.card,
    borderColor: colors.border,
    borderWidth: 1,
    borderRadius: 10,
    padding: 10,
    marginBottom: 8
  },
  name: { fontWeight: '700', color: colors.text },
  meta: { color: colors.textMuted, marginTop: 2 },
  empty: { marginTop: 18, textAlign: 'center', color: colors.textMuted }
});
