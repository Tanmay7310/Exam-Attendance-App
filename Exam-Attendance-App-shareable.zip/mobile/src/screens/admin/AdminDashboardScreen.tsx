import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useAuth } from '../../context/AuthContext';
import { colors } from '../../styles/theme';

export const AdminDashboardScreen = ({ navigation }: any) => {
  const { auth, logout } = useAuth();

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Welcome, {auth?.username}</Text>
      <Text style={styles.sub}>Admin controls</Text>

      <Pressable style={styles.button} onPress={() => navigation.navigate('TeacherManagement')}>
        <Text style={styles.buttonText}>Teacher Management</Text>
      </Pressable>

      <Pressable style={styles.button} onPress={() => navigation.navigate('StudentManagement')}>
        <Text style={styles.buttonText}>Student Management</Text>
      </Pressable>

      <Pressable style={styles.button} onPress={() => navigation.navigate('AttendanceMonitoring')}>
        <Text style={styles.buttonText}>Attendance Monitoring</Text>
      </Pressable>

      <Pressable style={styles.logout} onPress={logout}>
        <Text style={styles.logoutText}>Logout</Text>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 18, backgroundColor: colors.bg },
  heading: { fontSize: 24, fontWeight: '800', color: colors.text },
  sub: { marginTop: 4, color: colors.textMuted },
  button: {
    backgroundColor: colors.accent,
    marginTop: 14,
    padding: 14,
    borderRadius: 12,
    alignItems: 'center'
  },
  buttonText: { color: 'white', fontWeight: '700' },
  logout: {
    marginTop: 24,
    borderColor: colors.danger,
    borderWidth: 1,
    borderRadius: 12,
    padding: 12,
    alignItems: 'center'
  },
  logoutText: { color: colors.danger, fontWeight: '700' }
});
