import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { colors } from '../../styles/theme';

export const StudentManagementScreen = ({ navigation }: any) => {

  return (
    <View style={styles.container}>
      <Text style={styles.h2}>Student Management</Text>
      <Pressable style={styles.button} onPress={() => navigation.navigate('AddStudent')}>
        <Text style={styles.buttonText}>Add Student</Text>
      </Pressable>
      <Pressable style={styles.button} onPress={() => navigation.navigate('Students')}>
        <Text style={styles.buttonText}>Students</Text>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 12, backgroundColor: colors.bg },
  h2: { fontSize: 22, fontWeight: '800', color: colors.text, marginBottom: 12 },
  button: {
    backgroundColor: colors.accent,
    borderRadius: 10,
    padding: 12,
    alignItems: 'center',
    marginBottom: 10
  },
  buttonText: { color: 'white', fontWeight: '700' }
});
