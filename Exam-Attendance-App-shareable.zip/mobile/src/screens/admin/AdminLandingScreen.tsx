import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useAuth } from '../../context/AuthContext';
import { colors } from '../../styles/theme';

export const AdminLandingScreen = ({ navigation }: any) => {
  const { auth, logout } = useAuth();

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Welcome, {auth?.username}</Text>
      <Text style={styles.sub}>Choose an action</Text>

      <Pressable style={[styles.button, styles.bigButton]} onPress={() => navigation.navigate('EnterExamDetails', { returnTo: 'AdminLanding' })}>
        <Text style={styles.buttonText}>Scan Student QR/Barcode</Text>
      </Pressable>

      <Pressable style={styles.button} onPress={() => navigation.navigate('AttendanceList')}>
        <Text style={styles.buttonText}>View Attendance</Text>
      </Pressable>

      <Pressable style={styles.button} onPress={() => navigation.navigate('AdminDashboard')}>
        <Text style={styles.buttonText}>Admin Controls</Text>
      </Pressable>

      <Pressable style={styles.logout} onPress={logout}>
        <Text style={styles.logoutText}>Logout</Text>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 18, backgroundColor: colors.bg },
  heading: { fontSize: 24, fontWeight: '800', color: colors.text, marginBottom: 6 },
  sub: { color: colors.textMuted, marginBottom: 10 },
  button: {
    backgroundColor: colors.accent,
    marginTop: 14,
    padding: 14,
    borderRadius: 12,
    alignItems: 'center'
  },
  bigButton: {
    marginTop: 18,
    paddingVertical: 22
  },
  buttonText: { color: 'white', fontWeight: '700' },
  logout: {
    marginTop: 24,
    borderColor: colors.danger,
    borderWidth: 1,
    borderRadius: 12,
    padding: 12,
    alignItems: 'center'
  },
  logoutText: { color: colors.danger, fontWeight: '700' }
});