import React, { useCallback, useMemo, useState } from 'react';
import { Alert, FlatList, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { api } from '../../api/client';
import { useAuth } from '../../context/AuthContext';
import { StudentItem } from '../../types';
import { colors } from '../../styles/theme';

export const StudentsScreen = () => {
  const { logout } = useAuth();
  const [students, setStudents] = useState<StudentItem[]>([]);
  const [enrollmentSearch, setEnrollmentSearch] = useState('');
  const [diagnostics, setDiagnostics] = useState('');

  const loadStudents = useCallback(async () => {
    const { data } = await api.get<StudentItem[]>('/api/admin/students');
    setStudents(data);
    setDiagnostics('');
  }, []);

  React.useEffect(() => {
    loadStudents().catch(async (e: any) => {
      const status = e?.response?.status;
      if (status === 401 || status === 403) {
        Alert.alert('Session expired', 'Please login again.');
        await logout();
        return;
      }
      setDiagnostics(`Load students failed (${status ?? 'network'}): ${e?.message ?? 'Unknown error'}`);
      Alert.alert('Error', e?.response?.data?.message ?? e?.message ?? 'Failed to load students');
    });
  }, [loadStudents, logout]);

  const removeStudent = async (id: number) => {
    try {
      await api.delete(`/api/admin/students/${id}`);
      await loadStudents();
    } catch (e: any) {
      const status = e?.response?.status;
      if (status === 401 || status === 403) {
        Alert.alert('Session expired', 'Please login again.');
        await logout();
        return;
      }
      Alert.alert('Error', e?.response?.data?.message ?? e?.message ?? 'Unable to remove student');
    }
  };

  const filteredStudents = useMemo(() => {
    const search = enrollmentSearch.trim().toLowerCase();

    return [...students]
      .filter((student) => {
        if (!search) return true;
        return student.enrollmentNumber.toLowerCase().includes(search);
      })
      .sort((a, b) => a.enrollmentNumber.localeCompare(b.enrollmentNumber));
  }, [enrollmentSearch, students]);

  return (
    <View style={styles.container}>
      <Text style={styles.debugText}>API: {api.defaults.baseURL}</Text>
      {diagnostics ? <Text style={styles.debugError}>{diagnostics}</Text> : null}
      <TextInput
        placeholder="Search by Enrollment Number"
        style={styles.input}
        value={enrollmentSearch}
        onChangeText={setEnrollmentSearch}
      />

      <FlatList
        data={filteredStudents}
        keyExtractor={(item) => String(item.id)}
        ListEmptyComponent={<Text style={styles.empty}>No students found.</Text>}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Text style={styles.name}>{item.name}</Text>
            <Text style={styles.meta}>Enrollment: {item.enrollmentNumber}</Text>
            <Text style={styles.meta}>Scholar: {item.scholarNumber}</Text>
            <Text style={styles.meta}>{item.department} | Section {item.section}</Text>
            <Pressable style={styles.remove} onPress={() => removeStudent(item.id)}>
              <Text style={styles.removeText}>Remove</Text>
            </Pressable>
          </View>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 12, backgroundColor: colors.bg },
  input: {
    backgroundColor: colors.card,
    borderColor: colors.border,
    borderWidth: 1,
    borderRadius: 10,
    padding: 10,
    marginBottom: 10
  },
  card: {
    backgroundColor: colors.card,
    borderColor: colors.border,
    borderWidth: 1,
    borderRadius: 10,
    padding: 10,
    marginBottom: 8
  },
  name: { fontWeight: '700', color: colors.text },
  meta: { color: colors.textMuted, marginTop: 2 },
  remove: {
    marginTop: 8,
    alignSelf: 'flex-start',
    borderColor: colors.danger,
    borderWidth: 1,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 8
  },
  removeText: { color: colors.danger, fontWeight: '700' },
  empty: { marginTop: 18, textAlign: 'center', color: colors.textMuted },
  debugText: { color: colors.textMuted, marginBottom: 6, fontSize: 12 },
  debugError: { color: colors.danger, marginBottom: 6, fontSize: 12 }
});
