import React, { useCallback, useState } from 'react';
import { Alert, FlatList, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { api } from '../../api/client';
import { useAuth } from '../../context/AuthContext';
import { TeacherItem } from '../../types';
import { colors } from '../../styles/theme';

export const TeacherManagementScreen = () => {
  const { logout } = useAuth();
  const [teachers, setTeachers] = useState<TeacherItem[]>([]);
  const [diagnostics, setDiagnostics] = useState('');
  const [form, setForm] = useState({ username: '', password: '', teacherCode: '', name: '' });

  const loadTeachers = useCallback(async () => {
    const { data } = await api.get<TeacherItem[]>('/api/admin/teachers');
    setTeachers(data);
    setDiagnostics('');
  }, []);

  React.useEffect(() => {
    loadTeachers().catch(async (e: any) => {
      const status = e?.response?.status;
      if (status === 401 || status === 403) {
        Alert.alert('Session expired', 'Please login again.');
        await logout();
        return;
      }
      setDiagnostics(`Load teachers failed (${status ?? 'network'}): ${e?.message ?? 'Unknown error'}`);
      Alert.alert('Error', e?.response?.data?.message ?? e?.message ?? 'Failed to load teachers');
    });
  }, [loadTeachers, logout]);

  const addTeacher = async () => {
    try {
      await api.post('/api/admin/teachers', { ...form, subject: 'N/A' });
      setForm({ username: '', password: '', teacherCode: '', name: '' });
      await loadTeachers();
      Alert.alert('Success', 'Teacher added');
    } catch (e: any) {
      const status = e?.response?.status;
      if (status === 401 || status === 403) {
        Alert.alert('Session expired', 'Please login again.');
        await logout();
        return;
      }
      Alert.alert('Error', e?.response?.data?.message ?? e?.message ?? 'Unable to add teacher');
    }
  };

  const removeTeacher = async (id: number) => {
    try {
      await api.delete(`/api/admin/teachers/${id}`);
      await loadTeachers();
    } catch (e: any) {
      const status = e?.response?.status;
      if (status === 401 || status === 403) {
        Alert.alert('Session expired', 'Please login again.');
        await logout();
        return;
      }
      Alert.alert('Error', e?.response?.data?.message ?? e?.message ?? 'Unable to remove teacher');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.debugText}>API: {api.defaults.baseURL}</Text>
      {diagnostics ? <Text style={styles.debugError}>{diagnostics}</Text> : null}
      <Text style={styles.h2}>Add Teacher</Text>
      {['username', 'password', 'teacherCode', 'name'].map((field) => (
        <TextInput
          key={field}
          placeholder={field}
          style={styles.input}
          value={(form as any)[field]}
          onChangeText={(text) => setForm((p) => ({ ...p, [field]: text }))}
          secureTextEntry={field === 'password'}
        />
      ))}
      <Pressable style={styles.button} onPress={addTeacher}><Text style={styles.buttonText}>Add</Text></Pressable>

      <Text style={[styles.h2, { marginTop: 18 }]}>Teachers</Text>
      <FlatList
        data={teachers}
        keyExtractor={(item) => String(item.id)}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Text style={styles.name}>{item.name}</Text>
            <Text style={styles.meta}>{item.teacherCode} | {item.username}</Text>
            <Pressable style={styles.remove} onPress={() => removeTeacher(item.id)}>
              <Text style={styles.removeText}>Remove</Text>
            </Pressable>
          </View>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 12, backgroundColor: colors.bg },
  h2: { fontSize: 18, fontWeight: '700', color: colors.text, marginBottom: 8 },
  input: {
    backgroundColor: colors.card,
    borderColor: colors.border,
    borderWidth: 1,
    borderRadius: 10,
    padding: 10,
    marginBottom: 7
  },
  button: { backgroundColor: colors.accent, borderRadius: 10, padding: 12, alignItems: 'center' },
  buttonText: { color: 'white', fontWeight: '700' },
  card: {
    backgroundColor: colors.card,
    borderColor: colors.border,
    borderWidth: 1,
    borderRadius: 10,
    padding: 10,
    marginBottom: 8
  },
  name: { fontWeight: '700' },
  meta: { color: colors.textMuted, marginTop: 2 },
  remove: { marginTop: 8, alignSelf: 'flex-start', borderColor: colors.danger, borderWidth: 1, paddingHorizontal: 10, paddingVertical: 6, borderRadius: 8 },
  removeText: { color: colors.danger, fontWeight: '700' },
  debugText: { color: colors.textMuted, marginBottom: 6, fontSize: 12 },
  debugError: { color: colors.danger, marginBottom: 6, fontSize: 12 }
});
