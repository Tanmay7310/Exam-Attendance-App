import React, { useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { api } from '../../api/client';
import { useAuth } from '../../context/AuthContext';
import { colors } from '../../styles/theme';

type ExamDetails = {
  subject: string;
  branch: string;
  semester: string;
  year: string;
  section: string;
};

export const ScanScreen = ({ route, navigation }: any) => {
  const { logout } = useAuth();
  const [permission, requestPermission] = useCameraPermissions();
  const [manualScholar, setManualScholar] = useState('');
  const [scanLock, setScanLock] = useState(false);
  const examDetails: ExamDetails | undefined = route?.params?.examDetails;
  const returnTo = route?.params?.returnTo ?? 'TeacherDashboard';

  const getErrorMessage = (e: any) => {
    const status = e?.response?.status;
    const body = e?.response?.data;

    if (status === 401 || status === 403) {
      return 'Session expired. Please login again.';
    }

    if (typeof body === 'string' && body.trim().length > 0) {
      return body;
    }

    return body?.message ?? body?.error ?? e?.message ?? `Request failed (${status ?? 'network'})`;
  };

  if (!examDetails) {
    return (
      <View style={styles.center}>
        <Text style={styles.blockedText}>Please enter exam details before scanning students.</Text>
        <Pressable style={styles.btn} onPress={() => navigation.replace('EnterExamDetails', { returnTo })}>
          <Text style={styles.btnText}>Go To Enter Exam Details</Text>
        </Pressable>
      </View>
    );
  }

  const submitScan = async (scholarNumber: string, caseSensitive = false) => {
    if (!scholarNumber.trim()) {
      Alert.alert('Missing scholar number', 'Please enter a scholar number before submitting.');
      return;
    }

    try {
      const { data } = await api.post('/api/teacher/attendance/scan', {
        scholarNumber,
        examSubject: examDetails.subject,
        caseSensitive
      });
      Alert.alert(data.duplicate ? 'Duplicate' : 'Success', `${data.studentName} (${data.scholarNumber})\n${data.message}`);
    } catch (e: any) {
      const status = e?.response?.status;
      if (status === 401 || status === 403) {
        Alert.alert('Session expired', 'Please login again.');
        await logout();
        return;
      }

      Alert.alert('Scan failed', getErrorMessage(e));
    }
  };

  const onBarcodeScanned = async ({ data }: { data: string }) => {
    if (scanLock) {
      return;
    }
    setScanLock(true);
    await submitScan(data.trim(), false);
    setTimeout(() => setScanLock(false), 1200);
  };

  const confirmDone = () => {
    Alert.alert(
      'Finish Attendance?',
      'Are you sure you want to finish scanning and return to dashboard?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Done',
          style: 'default',
          onPress: () =>
            navigation.reset({
              index: 0,
              routes: [{ name: returnTo }]
            })
        }
      ]
    );
  };

  if (!permission) {
    return <View style={styles.center}><Text>Loading camera permissions...</Text></View>;
  }

  if (!permission.granted) {
    return (
      <View style={styles.center}>
        <Text style={{ marginBottom: 10 }}>Camera permission is required for barcode scanning.</Text>
        <Pressable style={styles.btn} onPress={requestPermission}><Text style={styles.btnText}>Allow Camera</Text></Pressable>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}
    >
      <ScrollView
        contentContainerStyle={styles.content}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
      <View style={styles.detailsCard}>
        <Text style={styles.detailsTitle}>Exam Details</Text>
        <Text style={styles.detailsLine}>Subject: {examDetails.subject}</Text>
        <Text style={styles.detailsLine}>Branch: {examDetails.branch}</Text>
        <Text style={styles.detailsLine}>Semester: {examDetails.semester}</Text>
        <Text style={styles.detailsLine}>Year: {examDetails.year}</Text>
        <Text style={styles.detailsLine}>Section: {examDetails.section}</Text>
      </View>

      <CameraView style={styles.camera} barcodeScannerSettings={{ barcodeTypes: ['qr', 'code128', 'ean13'] }} onBarcodeScanned={onBarcodeScanned} />
      <Text style={styles.hint}>Point the camera at student barcode/QR containing Scholar Number.</Text>

      <TextInput placeholder="Manual Scholar Number" style={styles.input} value={manualScholar} onChangeText={setManualScholar} />
      <Pressable style={styles.btn} onPress={() => submitScan(manualScholar.trim(), true)}>
        <Text style={styles.btnText}>Mark Attendance Manually</Text>
      </Pressable>

      <Pressable style={styles.doneBtn} onPress={confirmDone}>
        <Text style={styles.doneBtnText}>Done</Text>
      </Pressable>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  content: { padding: 14, paddingBottom: 28 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 },
  blockedText: { marginBottom: 12, color: colors.text, textAlign: 'center' },
  detailsCard: {
    backgroundColor: colors.card,
    borderColor: colors.border,
    borderWidth: 1,
    borderRadius: 12,
    padding: 10,
    marginBottom: 10
  },
  detailsTitle: { color: colors.text, fontWeight: '700', marginBottom: 4 },
  detailsLine: { color: colors.textMuted, fontSize: 12 },
  camera: { width: '100%', height: 340, borderRadius: 16, overflow: 'hidden' },
  hint: { marginVertical: 12, color: colors.textMuted },
  input: {
    backgroundColor: colors.card,
    borderColor: colors.border,
    borderWidth: 1,
    borderRadius: 12,
    padding: 12,
    marginBottom: 10
  },
  btn: {
    backgroundColor: colors.accent,
    padding: 13,
    borderRadius: 12,
    alignItems: 'center'
  },
  btnText: { color: 'white', fontWeight: '700' },
  doneBtn: {
    marginTop: 12,
    backgroundColor: colors.danger,
    padding: 13,
    borderRadius: 12,
    alignItems: 'center'
  },
  doneBtnText: { color: 'white', fontWeight: '700' }
});
