import React, { useMemo, useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { colors } from '../../styles/theme';

export const EnterExamDetailsScreen = ({ navigation, route }: any) => {
  const returnTo = route?.params?.returnTo;
  const [subject, setSubject] = useState('');
  const [branch, setBranch] = useState('');
  const [semester, setSemester] = useState('');
  const [year, setYear] = useState('');
  const [section, setSection] = useState('');

  const canProceed = useMemo(
    () => [subject, branch, semester, year, section].every((v) => v.trim().length > 0),
    [subject, branch, semester, year, section]
  );

  const proceedToScan = () => {
    if (!canProceed) {
      Alert.alert('Missing details', 'Please enter Subject, Branch, Semester, Year and Section.');
      return;
    }

    navigation.reset({
      index: 0,
      routes: [
        {
          name: 'Scan',
          params: {
            examDetails: {
              subject: subject.trim(),
              branch: branch.trim(),
              semester: semester.trim(),
              year: year.trim(),
              section: section.trim()
            },
            returnTo
          }
        }
      ]
    });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Enter Exam Details</Text>
      <Text style={styles.subText}>Fill in details before scanning student code.</Text>

      <TextInput
        placeholder="Subject"
        style={styles.input}
        value={subject}
        onChangeText={setSubject}
      />
      <TextInput
        placeholder="Branch"
        style={styles.input}
        value={branch}
        onChangeText={setBranch}
      />
      <TextInput
        placeholder="Semester"
        keyboardType="number-pad"
        style={styles.input}
        value={semester}
        onChangeText={setSemester}
      />
      <TextInput
        placeholder="Year"
        keyboardType="number-pad"
        style={styles.input}
        value={year}
        onChangeText={setYear}
      />
      <TextInput
        placeholder="Section"
        style={styles.input}
        value={section}
        onChangeText={setSection}
      />

      <Pressable style={[styles.button, !canProceed && styles.buttonDisabled]} onPress={proceedToScan}>
        <Text style={styles.buttonText}>Continue To Scan</Text>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 18, backgroundColor: colors.bg },
  heading: { fontSize: 24, fontWeight: '800', color: colors.text, marginBottom: 6 },
  subText: { color: colors.textMuted, marginBottom: 16 },
  input: {
    backgroundColor: colors.card,
    borderColor: colors.border,
    borderWidth: 1,
    borderRadius: 12,
    padding: 12,
    marginBottom: 10,
    color: colors.text
  },
  button: {
    backgroundColor: colors.accent,
    padding: 14,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 8
  },
  buttonDisabled: {
    opacity: 0.7
  },
  buttonText: {
    color: 'white',
    fontWeight: '700'
  }
});
