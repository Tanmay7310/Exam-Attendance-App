import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useAuth } from '../../context/AuthContext';
import { colors } from '../../styles/theme';

export const TeacherDashboardScreen = ({ navigation }: any) => {
  const { auth, logout } = useAuth();

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Welcome, {auth?.teacherName ?? auth?.username}</Text>
      <Text style={styles.meta}>Subject: {auth?.subject}</Text>
      <Text style={styles.meta}>Teacher ID: {auth?.teacherCode}</Text>

      <Pressable style={[styles.button, styles.bigButton]} onPress={() => navigation.navigate('EnterExamDetails', { returnTo: 'TeacherDashboard' })}>
        <Text style={styles.buttonText}>Scan Student QR/Barcode</Text>
      </Pressable>

      <Pressable style={styles.button} onPress={() => navigation.navigate('AttendanceList')}>
        <Text style={styles.buttonText}>View Attendance</Text>
      </Pressable>

      <Pressable style={styles.logout} onPress={logout}>
        <Text style={styles.logoutText}>Logout</Text>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 18, backgroundColor: colors.bg },
  heading: { fontSize: 24, fontWeight: '800', color: colors.text, marginBottom: 8 },
  meta: { color: colors.textMuted, marginBottom: 2 },
  button: {
    backgroundColor: colors.accent,
    marginTop: 14,
    padding: 14,
    borderRadius: 12,
    alignItems: 'center'
  },
  bigButton: {
    marginTop: 24,
    paddingVertical: 22
  },
  buttonText: { color: 'white', fontWeight: '700' },
  logout: {
    marginTop: 24,
    borderColor: colors.danger,
    borderWidth: 1,
    borderRadius: 12,
    padding: 12,
    alignItems: 'center'
  },
  logoutText: { color: colors.danger, fontWeight: '700' }
});
