import React, { useCallback, useMemo, useState } from 'react';
import { Alert, FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import * as FileSystem from 'expo-file-system/legacy';
import * as Sharing from 'expo-sharing';
import { api } from '../../api/client';
import { useAuth } from '../../context/AuthContext';
import { AttendanceRecord } from '../../types';
import { colors } from '../../styles/theme';

const today = () => new Date().toISOString().slice(0, 10);

export const AttendanceListScreen = () => {
  const { auth } = useAuth();
  const [records, setRecords] = useState<AttendanceRecord[]>([]);
  const [sortBy, setSortBy] = useState<'time' | 'scholarNumber'>('time');

  const fetchRecords = useCallback(async (selectedSort: 'time' | 'scholarNumber') => {
    const { data } = await api.get<AttendanceRecord[]>('/api/teacher/attendance/session', {
      params: { date: today(), sortBy: selectedSort }
    });
    setRecords(data);
  }, []);

  React.useEffect(() => {
    fetchRecords(sortBy).catch(() => Alert.alert('Error', 'Failed to load attendance list'));
  }, [fetchRecords, sortBy]);

  const exportPdf = async () => {
    try {
      const fileUri = `${FileSystem.documentDirectory}attendance-${today()}.pdf`;
      const url = `${api.defaults.baseURL}/api/teacher/attendance/report/pdf?date=${today()}`;
      await FileSystem.downloadAsync(url, fileUri, {
        headers: {
          Authorization: `Bearer ${auth?.token ?? ''}`
        }
      });

      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(fileUri);
      } else {
        Alert.alert('Saved', `PDF saved at ${fileUri}`);
      }
    } catch (e: any) {
      Alert.alert('Export failed', e?.response?.data?.message ?? 'Unable to generate PDF');
    }
  };

  const sortedLabel = useMemo(() => (sortBy === 'time' ? 'Sort: Time' : 'Sort: Scholar Number'), [sortBy]);

  return (
    <View style={styles.container}>
      <View style={styles.row}>
        <Pressable style={styles.smallButton} onPress={() => setSortBy(sortBy === 'time' ? 'scholarNumber' : 'time')}>
          <Text style={styles.smallButtonText}>{sortedLabel}</Text>
        </Pressable>
        <Pressable style={styles.smallButton} onPress={exportPdf}>
          <Text style={styles.smallButtonText}>Export PDF</Text>
        </Pressable>
      </View>

      <FlatList
        data={records}
        keyExtractor={(item) => `${item.scholarNumber}-${item.scannedAt}`}
        ListEmptyComponent={<Text style={styles.empty}>No attendance entries for today.</Text>}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Text style={styles.name}>{item.studentName}</Text>
            <Text style={styles.meta}>Scholar: {item.scholarNumber}</Text>
            <Text style={styles.meta}>Time: {new Date(item.scannedAt).toLocaleTimeString()}</Text>
          </View>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 12, backgroundColor: colors.bg },
  row: { flexDirection: 'row', gap: 8, marginBottom: 8 },
  smallButton: {
    flex: 1,
    backgroundColor: colors.accent,
    borderRadius: 10,
    padding: 10,
    alignItems: 'center'
  },
  smallButtonText: { color: 'white', fontWeight: '700', fontSize: 12 },
  card: {
    backgroundColor: colors.card,
    padding: 12,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: colors.border,
    marginBottom: 8
  },
  name: { fontWeight: '700', color: colors.text },
  meta: { color: colors.textMuted, marginTop: 2 },
  empty: { marginTop: 18, textAlign: 'center', color: colors.textMuted }
});
