package com.exam.attendance.service;

import com.exam.attendance.dto.teacher.AttendanceRecordResponse;
import com.exam.attendance.dto.teacher.ScanAttendanceResponse;
import com.exam.attendance.dto.teacher.TeacherProfileResponse;
import com.exam.attendance.entity.*;
import com.exam.attendance.exception.ApiException;
import com.exam.attendance.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.Instant;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;

@Service
@RequiredArgsConstructor
public class TeacherService {

    private final UserRepository userRepository;
    private final TeacherRepository teacherRepository;
    private final StudentRepository studentRepository;
    private final AttendanceSessionRepository attendanceSessionRepository;
    private final AttendanceRecordRepository attendanceRecordRepository;
    private final PdfService pdfService;

    public TeacherProfileResponse getProfile(String username) {
        Teacher teacher = getTeacherByUsername(username);
        return TeacherProfileResponse.builder()
                .teacherCode(teacher.getTeacherCode())
                .name(teacher.getName())
                .subject(teacher.getSubject())
                .build();
    }

    @Transactional
    public ScanAttendanceResponse scan(String username, String scholarNumber, String examSubject, boolean caseSensitive) {
        Teacher teacher = getTeacherByUsername(username);
        String normalizedScholarNumber = scholarNumber.trim();
        LocalDate today = LocalDate.now();
        AttendanceSession session = attendanceSessionRepository.findByTeacherAndSessionDate(teacher, today)
                .orElseGet(() -> attendanceSessionRepository.save(AttendanceSession.builder()
                        .teacher(teacher)
                        .sessionDate(today)
                        .examSubject(StringUtils.hasText(examSubject) ? examSubject.trim() : null)
                        .createdAt(Instant.now())
                        .build()));

        if (session.getExamSubject() == null && StringUtils.hasText(examSubject)) {
            session.setExamSubject(examSubject.trim());
            attendanceSessionRepository.save(session);
        }

        Student student = (caseSensitive
                ? studentRepository.findByScholarNumberCaseSensitive(normalizedScholarNumber)
                : studentRepository.findByScholarNumber(normalizedScholarNumber))
                .orElseThrow(() -> new ApiException("Student not found for scholar number: " + normalizedScholarNumber));

        if (attendanceRecordRepository.existsBySessionAndStudent(session, student)) {
            return ScanAttendanceResponse.builder()
                    .scholarNumber(student.getScholarNumber())
                    .studentName(student.getName())
                    .scannedAt(Instant.now())
                    .duplicate(true)
                    .message("Duplicate scan blocked for current session")
                    .build();
        }

        AttendanceRecord record = AttendanceRecord.builder()
                .session(session)
                .student(student)
                .scannedAt(Instant.now())
                .build();
        attendanceRecordRepository.save(record);

        return ScanAttendanceResponse.builder()
                .scholarNumber(student.getScholarNumber())
                .studentName(student.getName())
                .scannedAt(record.getScannedAt())
                .duplicate(false)
                .message("Attendance marked successfully")
                .build();
    }

    public List<AttendanceRecordResponse> getSessionAttendance(String username, LocalDate date, String sortBy) {
        Teacher teacher = getTeacherByUsername(username);
        AttendanceSession session = attendanceSessionRepository.findByTeacherAndSessionDate(teacher, date)
                .orElse(null);

        if (session == null) {
            return List.of();
        }

        List<AttendanceRecord> records = attendanceRecordRepository.findBySessionOrderByScannedAtAsc(session);
        if ("scholarNumber".equalsIgnoreCase(sortBy)) {
            records = records.stream()
                    .sorted(Comparator.comparing(r -> r.getStudent().getScholarNumber()))
                    .toList();
        }

        return records.stream()
                .map(r -> AttendanceRecordResponse.builder()
                        .scholarNumber(r.getStudent().getScholarNumber())
                        .enrollmentNumber(r.getStudent().getEnrollmentNumber())
                        .studentName(r.getStudent().getName())
                        .scannedAt(r.getScannedAt())
                        .build())
                .toList();
    }

    public byte[] generatePdfReport(String username, LocalDate date) {
        Teacher teacher = getTeacherByUsername(username);
        List<AttendanceRecordResponse> records = getSessionAttendance(username, date, "time");
                AttendanceSession session = attendanceSessionRepository.findByTeacherAndSessionDate(teacher, date).orElse(null);
                String reportSubject = (session != null && StringUtils.hasText(session.getExamSubject()))
                                ? session.getExamSubject()
                                : teacher.getSubject();
                return pdfService.generateAttendancePdf(teacher, date, reportSubject, records);
    }

    public AttendanceRecordResponse searchStudent(String scholarNumber) {
        Student student = studentRepository.findByScholarNumber(scholarNumber)
                .orElseThrow(() -> new ApiException("Student not found"));
        return AttendanceRecordResponse.builder()
                .scholarNumber(student.getScholarNumber())
                .enrollmentNumber(student.getEnrollmentNumber())
                .studentName(student.getName())
                .scannedAt(null)
                .build();
    }

    private Teacher getTeacherByUsername(String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new ApiException("User not found"));
        return teacherRepository.findByUser(user)
                .orElseThrow(() -> new ApiException("Teacher profile not found"));
    }
}
