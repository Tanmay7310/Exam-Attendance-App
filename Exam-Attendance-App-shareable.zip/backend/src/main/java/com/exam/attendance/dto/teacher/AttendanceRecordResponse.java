package com.exam.attendance.dto.teacher;

import lombok.Builder;
import lombok.Data;

import java.time.Instant;

@Data
@Builder
public class AttendanceRecordResponse {
    private String scholarNumber;
    private String enrollmentNumber;
    private String studentName;
    private Instant scannedAt;
}
